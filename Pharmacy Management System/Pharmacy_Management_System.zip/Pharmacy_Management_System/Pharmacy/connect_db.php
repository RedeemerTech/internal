<?php
error_reporting (1);
$con=mysql_pconnect('localhost','root','')or die("cannot connect to server");
mysql_select_db('pharmacy')or die("cannot connect to database");

?>