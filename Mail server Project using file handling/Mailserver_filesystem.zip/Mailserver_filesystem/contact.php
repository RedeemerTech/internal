<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Contact Information</title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
	<table border="0" align="center">
	<caption><h1>Contact Information</h1></caption>
		<form method="post" enctype="multipart/form-data">
			<tr>
				<td colspan="2"><img src="User_Data/logo.png" width="400px" height="200px"/></td>
			</tr>
			<tr>
				<th colspan="2">Phptpoint</th>
			</tr>
			<tr>
				<td>Email Id</td>
				<td>phptpoint@gmail.com</td>
			</tr>
			<tr>
				<td>Mobile Number</td>
                <td>+91 9015 501 897</td>
            </tr> 
             
        </form>
    </table>
</body>
</html>
